Drop qwen2.5-1.5b-instruct-q4_k_m.gguf here. See MODELS.md.
